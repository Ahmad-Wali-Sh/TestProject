// ═══════════════════════════════════════════════
//  AUTH GUARD + GREETING
// ═══════════════════════════════════════════════
(function(){
    const role = sessionStorage.getItem('pubg_role');
    const name = sessionStorage.getItem('pubg_name') || 'Player';
    if(!role){ window.location.href='login.html'; return; }
    if(role==='admin') document.body.classList.add('is-admin');
    window.addEventListener('DOMContentLoaded', ()=>{
        const badge = document.getElementById('role-badge');
        if(badge){ badge.textContent = role==='admin' ? '▣ ADMIN' : '◈ USER'; badge.className = 'role-chip ' + role; }
        const bar = document.getElementById('greeting-bar');
        const text = document.getElementById('greeting-text');
        if(bar && text){
            const h = new Date().getHours();
            const g = h<12 ? 'GOOD MORNING' : h<17 ? 'GOOD AFTERNOON' : 'GOOD EVENING';
            if(role==='admin'){
                text.innerHTML = `// ${g}, <strong style="color:#e01830;font-family:'Share Tech Mono',monospace;">${name.toUpperCase()}</strong> &nbsp;·&nbsp; Welcome back, Admin. Full control is yours.`;
            } else {
                text.innerHTML = `// ${g}, <strong style="color:#4fc3f7;font-family:'Share Tech Mono',monospace;">${name.toUpperCase()}</strong> &nbsp;·&nbsp; Welcome to PUBG Marketplace. You can add and browse listings.`;
            }
        }
    });
})();

function logout(){
    sessionStorage.removeItem('pubg_role');
    sessionStorage.removeItem('pubg_name');
    window.location.href='login.html';
}

// ═══════════════════════════════════════════════
//  INDEXEDDB  — stores media blobs permanently
//  No size limit, survives refresh / close / reopen
// ═══════════════════════════════════════════════
const DB_NAME    = 'pubg_media_db';
const DB_VERSION = 1;
const STORE      = 'media';
let   _db        = null;

function openDB(){
    return new Promise((res, rej)=>{
        if(_db){ res(_db); return; }
        const req = indexedDB.open(DB_NAME, DB_VERSION);
        req.onupgradeneeded = e => { e.target.result.createObjectStore(STORE, { keyPath:'key' }); };
        req.onsuccess       = e => { _db = e.target.result; res(_db); };
        req.onerror         = e => rej(e.target.error);
    });
}

// Save array of {dataUrl, type} blobs under a key like "acc_1234"
async function saveMedia(key, mediaArr){
    const db = await openDB();
    return new Promise((res, rej)=>{
        const tx  = db.transaction(STORE, 'readwrite');
        const st  = tx.objectStore(STORE);
        st.put({ key, media: mediaArr });
        tx.oncomplete = ()=> res();
        tx.onerror    = e => rej(e.target.error);
    });
}

// Load media array for a key; returns [] if not found
async function loadMedia(key){
    const db = await openDB();
    return new Promise((res, rej)=>{
        const tx  = db.transaction(STORE, 'readonly');
        const req = tx.objectStore(STORE).get(key);
        req.onsuccess = e => res(e.target.result ? e.target.result.media : []);
        req.onerror   = e => rej(e.target.error);
    });
}

// Delete media for a key
async function deleteMedia(key){
    const db = await openDB();
    return new Promise((res, rej)=>{
        const tx = db.transaction(STORE, 'readwrite');
        tx.objectStore(STORE).delete(key);
        tx.oncomplete = ()=> res();
        tx.onerror    = e => rej(e.target.error);
    });
}

// Convert File → {dataUrl, type}
function fileToObj(file){
    return new Promise((res, rej)=>{
        const r = new FileReader();
        r.onload  = ()=> res({ dataUrl: r.result, type: file.type });
        r.onerror = rej;
        r.readAsDataURL(file);
    });
}

// ═══════════════════════════════════════════════
//  PROFIT CALCULATOR  (PUBG Accounts only)
//  Every price → +10% seller benefit
// ═══════════════════════════════════════════════
function calcProfit(input){
    const badge = document.getElementById('profit-badge');
    const price = parseFloat((input.value||'').replace(/,/g,'').match(/[\d]+(?:\.\d+)?/)?.[0]);
    if(!badge) return;
    if(isNaN(price)||price<=0){ badge.style.display='none'; return; }
    const benefit = Math.round(price * 0.10);
    badge.style.display = 'block';
    badge.textContent   = `◈ SELLER BENEFIT: +${benefit.toLocaleString()} (10% of price)`;
}
function getSellerBenefit(priceStr){
    const price = parseFloat((priceStr||'').replace(/,/g,'').match(/[\d]+(?:\.\d+)?/)?.[0]);
    return (isNaN(price)||price<=0) ? 0 : Math.round(price * 0.10);
}

// ═══════════════════════════════════════════════
//  PRICE FILTER
// ═══════════════════════════════════════════════
let priceFilter = null;
function extractNum(s){ const m=(s||'').replace(/,/g,'').match(/[\d]+(?:\.\d+)?/); return m?parseFloat(m[0]):null; }
function applyMaxFilter(){
    const max=parseFloat(document.getElementById('pf-max').value);
    if(isNaN(max)){alert('Enter a valid max price.');return;}
    priceFilter={mode:'max',max}; filterCards();
}
function applyRangeFilter(){
    const min=parseFloat(document.getElementById('pf-min').value)||0;
    const max=parseFloat(document.getElementById('pf-rmax').value);
    if(isNaN(max)){alert('Enter a valid max price.');return;}
    priceFilter={mode:'range',min,max}; filterCards();
}
function clearPriceFilter(){
    priceFilter=null;
    ['pf-max','pf-min','pf-rmax'].forEach(id=>{const el=document.getElementById(id);if(el)el.value='';});
    filterCards();
}
function filterCards(){
    document.querySelectorAll('.card').forEach(card=>{
        const p=card.querySelector('.card-price');
        if(!p){card.classList.remove('price-hidden');return;}
        const price=extractNum(p.textContent);
        if(!priceFilter||price===null){card.classList.remove('price-hidden');return;}
        const {mode,min,max}=priceFilter;
        card.classList.toggle('price-hidden', mode==='max'?price>max:(price<min||price>max));
    });
}

function clearSearch(){
    document.getElementById('global-search').value='';
    document.getElementById('search-clear').classList.remove('visible');
    document.getElementById('search-results').classList.remove('open');
}

function esc(s){ return (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }

// ═══════════════════════════════════════════════
//  MARKETPLACE
// ═══════════════════════════════════════════════
class Market {
    constructor(){
        // Text data in localStorage (tiny — no media)
        this.accounts = JSON.parse(localStorage.getItem('pubg_accounts')||'[]');
        this.uc       = JSON.parse(localStorage.getItem('pubg_uc')||'[]');
        this.trade    = JSON.parse(localStorage.getItem('pubg_trade')||'[]');
        // Pending files for current upload session (before submit)
        this.accFiles = [];
        this.trFiles  = [];
        this.stTimeout = null;
        this.init();
    }

    async init(){
        this.bindNav();
        this.bindForms();
        this.bindMedia();
        this.bindModal();
        this.bindSearch();
        // Load media from IndexedDB for all existing listings then render
        await this.loadAllMedia();
        this.renderAll();
    }

    // ── LOAD ALL MEDIA FROM INDEXEDDB ────────
    // Attaches .media arrays back onto each listing object
    async loadAllMedia(){
        const loads = [];
        for(const a of this.accounts) loads.push(loadMedia(`acc_${a.id}`).then(m=>{ a.media=m; }));
        for(const l of this.trade)    loads.push(loadMedia(`tr_${l.id}`).then(m=>{ l.media=m; }));
        await Promise.all(loads);
    }

    // ── NAVIGATION ───────────────────────────
    bindNav(){
        document.querySelectorAll('.ntab').forEach(btn=>{
            btn.addEventListener('click', e=>{
                const b=e.target.closest('.ntab');
                document.querySelectorAll('.ntab').forEach(x=>x.classList.remove('active'));
                b.classList.add('active');
                document.querySelectorAll('.pg').forEach(s=>s.classList.remove('active'));
                document.getElementById(`${b.dataset.page}-page`).classList.add('active');
                filterCards();
            });
        });
    }

    // ── FORMS ────────────────────────────────
    bindForms(){
        document.getElementById('account-form').addEventListener('submit', e=>this.addAccount(e));
        document.getElementById('uc-form').addEventListener('submit',      e=>this.addUC(e));
        document.getElementById('trade-form').addEventListener('submit',   e=>this.addTrade(e));
    }

    // ── MEDIA PICKER (preview only, before submit) ───
    bindMedia(){
        document.getElementById('acc-media-input').addEventListener('change', e=>this.pickFiles(e.target.files,'acc'));
        document.getElementById('media-input').addEventListener('change',     e=>this.pickFiles(e.target.files,'tr'));
    }
    pickFiles(files, ctx){
        const arr = ctx==='acc' ? this.accFiles : this.trFiles;
        const pid = ctx==='acc' ? 'acc-media-previews' : 'media-previews';
        const iid = ctx==='acc' ? 'acc-media-input' : 'media-input';
        Array.from(files).forEach(f=>{ const i=arr.length; arr.push(f); this.showPreview(f,i,pid,arr); });
        document.getElementById(iid).value='';
    }
    showPreview(file, idx, cid, arr){
        const c=document.getElementById(cid);
        const item=document.createElement('div'); item.className='prev-item';
        const url=URL.createObjectURL(file);
        const el=document.createElement(file.type.startsWith('video/')?'video':'img');
        el.src=url; if(el.tagName==='VIDEO'){el.muted=true;el.playsInline=true;}
        item.appendChild(el);
        const rm=document.createElement('button'); rm.className='rm'; rm.textContent='✕';
        rm.addEventListener('click',()=>{ arr.splice(idx,1); item.remove(); });
        item.appendChild(rm); c.appendChild(item);
    }

    // ── ADD ACCOUNT ──────────────────────────
    async addAccount(e){
        e.preventDefault();
        const btn=document.querySelector('#account-form .btn-submit');
        btn.textContent='SAVING...'; btn.disabled=true;

        // Convert files to {dataUrl, type} objects
        const mediaObjs=[];
        for(const f of this.accFiles) try{ mediaObjs.push(await fileToObj(f)); }catch(er){}

        const id = Date.now();
        const item={
            id,
            username:    document.getElementById('acc-username').value,
            rank:        document.getElementById('acc-rank').value,
            level:       document.getElementById('acc-level').value,
            items:       document.getElementById('acc-items').value,
            price:       document.getElementById('acc-price').value,
            description: document.getElementById('acc-description').value,
            listedBy:    sessionStorage.getItem('pubg_name')||'Unknown',
            date:        new Date().toLocaleDateString()
            // NOTE: no .media field in localStorage — stored separately in IndexedDB
        };

        // Save media to IndexedDB (permanent, no size limit)
        await saveMedia(`acc_${id}`, mediaObjs);
        // Attach for immediate display this session
        item.media = mediaObjs;

        this.accounts.unshift(item);
        this.saveAccounts(); // saves text data only

        document.getElementById('account-form').reset();
        document.getElementById('acc-media-previews').innerHTML='';
        document.getElementById('profit-badge').style.display='none';
        this.accFiles=[];
        btn.textContent='▶ LIST ACCOUNT'; btn.disabled=false;
        this.renderAccounts();
        alert('✓ Account listed! Photos/videos saved permanently.');
    }

    // ── ADD UC ───────────────────────────────
    addUC(e){
        e.preventDefault();
        const item={
            id:Date.now(),
            name:     document.getElementById('uc-name').value,
            amount:   document.getElementById('uc-amount').value,
            price:    document.getElementById('uc-price').value,
            mobileId: document.getElementById('uc-mobile-id').value,
            details:  document.getElementById('uc-details').value,
            listedBy: sessionStorage.getItem('pubg_name')||'Unknown',
            date:     new Date().toLocaleDateString()
        };
        this.uc.unshift(item); this.saveUC();
        document.getElementById('uc-form').reset();
        this.renderUC();
        alert('✓ UC Package added!');
    }

    // ── ADD TRADE ────────────────────────────
    async addTrade(e){
        e.preventDefault();
        const btn=document.querySelector('.tr-btn');
        btn.textContent='SAVING...'; btn.disabled=true;

        const mediaObjs=[];
        for(const f of this.trFiles) try{ mediaObjs.push(await fileToObj(f)); }catch(er){}

        const id = Date.now();
        const item={
            id,
            title:   document.getElementById('trade-title').value,
            game:    document.getElementById('trade-game').value,
            price:   document.getElementById('trade-price').value,
            contact: document.getElementById('trade-contact').value,
            desc:    document.getElementById('trade-desc').value,
            listedBy:sessionStorage.getItem('pubg_name')||'Unknown',
            date:    new Date().toLocaleDateString()
        };

        await saveMedia(`tr_${id}`, mediaObjs);
        item.media = mediaObjs;

        this.trade.unshift(item); this.saveTrade();
        document.getElementById('trade-form').reset();
        document.getElementById('media-previews').innerHTML='';
        this.trFiles=[];
        btn.textContent='▶ POST LISTING'; btn.disabled=false;
        this.renderTrade();
        alert('✓ Listing posted! Photos/videos saved permanently.');
    }

    // ── SAVE TEXT DATA ───────────────────────
    saveAccounts(){
        // Store ONLY text fields — no media (that's in IndexedDB)
        const slim = this.accounts.map(({media,...rest})=>rest);
        localStorage.setItem('pubg_accounts', JSON.stringify(slim));
    }
    saveUC()   { localStorage.setItem('pubg_uc',    JSON.stringify(this.uc)); }
    saveTrade(){
        const slim = this.trade.map(({media,...rest})=>rest);
        localStorage.setItem('pubg_trade', JSON.stringify(slim));
    }

    // ── CARD MEDIA HTML ──────────────────────
    mediaHtml(arr, emoji){
        if(arr&&arr.length){
            const f=arr[0];
            const cnt=arr.length>1?`<span class="media-count">+${arr.length-1}</span>`:'';
            const tag=f.type&&f.type.startsWith('video/')
                ?`<video src="${f.dataUrl}" muted playsinline loop autoplay></video>`
                :`<img src="${f.dataUrl}" alt="">`;
            return `<div class="card-media">${tag}${cnt}</div>`;
        }
        return `<div class="card-placeholder">${emoji}</div>`;
    }

    // ── RENDER ACCOUNTS ──────────────────────
    renderAccounts(){
        const g=document.getElementById('accounts-grid');
        if(!this.accounts.length){
            g.innerHTML=`<div class="empty"><h3>NO ACCOUNTS YET</h3><p>List your first PUBG account above.</p></div>`; return;
        }
        g.innerHTML=this.accounts.map(a=>{
            const benefit=getSellerBenefit(a.price);
            return `<div class="card">
                ${this.mediaHtml(a.media,'⚔')}
                <div class="card-body">
                    <div class="card-tag">// PUBG ACCOUNT</div>
                    <h4>${esc(a.username)}</h4>
                    <div class="card-info">
                        COLLECTION &nbsp;<span>${esc(a.rank)}</span><br>
                        LEVEL &nbsp;<span>${esc(a.level)}</span><br>
                        SKINS &nbsp;<span>${esc(a.items||'Various')}</span><br>
                        BY &nbsp;<span>${esc(a.listedBy)}</span>
                    </div>
                    <div class="card-price-row">
                        <div class="card-price">${esc(a.price)}</div>
                        ${benefit>0?`<div class="card-profit">+${benefit.toLocaleString()} BENEFIT</div>`:''}
                    </div>
                    <div class="card-btns">
                        <button class="btn-view" onclick="market.viewAcc(${a.id})">▶ VIEW</button>
                        <button class="btn-del"  onclick="market.delAcc(${a.id})">✕ DELETE</button>
                    </div>
                </div>
            </div>`;
        }).join('');
        filterCards();
    }

    // ── RENDER UC ────────────────────────────
    renderUC(){
        const g=document.getElementById('uc-grid');
        if(!this.uc.length){
            g.innerHTML=`<div class="empty"><h3>NO UC PACKAGES</h3><p>Add UC packages to get started.</p></div>`; return;
        }
        g.innerHTML=this.uc.map(u=>`
            <div class="card uc-card">
                ${this.mediaHtml([],'💎')}
                <div class="card-body">
                    <div class="card-tag">// UC PACKAGE</div>
                    <h4>${esc(u.name)}</h4>
                    <div class="card-info">
                        UC AMOUNT &nbsp;<span>${esc(u.amount)}</span><br>
                        MOBILE ID &nbsp;<span>${esc(u.mobileId||'Not specified')}</span><br>
                        BY &nbsp;<span>${esc(u.listedBy)}</span>
                    </div>
                    <div class="card-price-row">
                        <div class="card-price">${esc(u.price)}</div>
                    </div>
                    <div class="card-btns">
                        <button class="btn-view" onclick="market.viewUC(${u.id})">▶ VIEW</button>
                        <button class="btn-del"  onclick="market.delUC(${u.id})">✕ DELETE</button>
                    </div>
                </div>
            </div>`).join('');
        filterCards();
    }

    // ── RENDER TRADE ─────────────────────────
    renderTrade(){
        const g=document.getElementById('trade-grid');
        if(!this.trade.length){
            g.innerHTML=`<div class="empty"><h3>NO LISTINGS YET</h3><p>Post your first listing above.</p></div>`; return;
        }
        g.innerHTML=this.trade.map(l=>`
            <div class="card trade-card">
                ${this.mediaHtml(l.media,'📱')}
                <div class="card-body">
                    <div class="card-tag">// TRADE LISTING</div>
                    <h4>${esc(l.title)}</h4>
                    <div class="card-info">
                        GAME &nbsp;<span>${esc(l.game)}</span><br>
                        CONTACT &nbsp;<span>${esc(l.contact||'See details')}</span><br>
                        BY &nbsp;<span>${esc(l.listedBy)}</span>
                    </div>
                    <div class="card-price-row">
                        <div class="card-price">${esc(l.price)}</div>
                    </div>
                    <div class="card-btns">
                        <button class="btn-view" onclick="market.viewTr(${l.id})">▶ VIEW</button>
                        <button class="btn-del"  onclick="market.delTr(${l.id})">✕ DELETE</button>
                    </div>
                </div>
            </div>`).join('');
        filterCards();
    }

    renderAll(){ this.renderAccounts(); this.renderUC(); this.renderTrade(); }

    // ── MODAL GALLERY ────────────────────────
    gallery(media, color){
        if(!media||!media.length) return '';
        return `<div class="modal-gallery">`+media.map(m=>m.type&&m.type.startsWith('video/')
            ?`<video src="${m.dataUrl}" controls style="width:120px;height:90px;object-fit:cover;border-radius:2px;border:1px solid ${color}"></video>`
            :`<img src="${m.dataUrl}" style="width:120px;height:90px;object-fit:cover;border-radius:2px;border:1px solid ${color}" alt="">`
        ).join('')+`</div>`;
    }

    // ── VIEW MODALS ──────────────────────────
    viewAcc(id){
        const a=this.accounts.find(x=>x.id===id); if(!a) return;
        const benefit=getSellerBenefit(a.price);
        document.getElementById('modal-body').innerHTML=`
            <h3>⚔ ACCOUNT DETAILS</h3>
            ${this.gallery(a.media,'rgba(192,21,42,.4)')}
            <p><strong>USERNAME</strong> ${esc(a.username)}</p>
            <p><strong>COLLECTION</strong> ${esc(a.rank)}</p>
            <p><strong>LEVEL</strong> ${esc(a.level)}</p>
            <p><strong>ITEMS & SKINS</strong> ${esc(a.items||'Not specified')}</p>
            <p><strong>PRICE</strong> ${esc(a.price)}</p>
            ${benefit>0?`<p><strong>SELLER BENEFIT</strong> +${benefit.toLocaleString()} (10% of price)</p>`:''}
            <p><strong>DESCRIPTION</strong> ${esc(a.description||'None')}</p>
            <p><strong>LISTED BY</strong> ${esc(a.listedBy)}</p>
            <p><strong>DATE</strong> ${a.date}</p>
            <button class="modal-btn">▶ BUY NOW</button>`;
        this.openModal();
    }
    viewUC(id){
        const u=this.uc.find(x=>x.id===id); if(!u) return;
        document.getElementById('modal-body').innerHTML=`
            <h3>💎 UC PACKAGE</h3>
            <p><strong>PACKAGE</strong> ${esc(u.name)}</p>
            <p><strong>UC AMOUNT</strong> ${esc(u.amount)}</p>
            <p><strong>PRICE</strong> ${esc(u.price)}</p>
            <p><strong>MOBILE ID</strong> ${esc(u.mobileId||'Any valid ID')}</p>
            <p><strong>DETAILS</strong> ${esc(u.details||'No details')}</p>
            <p><strong>ADDED BY</strong> ${esc(u.listedBy)}</p>
            <p><strong>DATE</strong> ${u.date}</p>
            <button class="modal-btn uc-mb">▶ PURCHASE NOW</button>`;
        this.openModal();
    }
    viewTr(id){
        const l=this.trade.find(x=>x.id===id); if(!l) return;
        document.getElementById('modal-body').innerHTML=`
            <h3>⇄ TRADE LISTING</h3>
            ${this.gallery(l.media,'rgba(124,77,255,.4)')}
            <p><strong>TITLE</strong> ${esc(l.title)}</p>
            <p><strong>GAME</strong> ${esc(l.game)}</p>
            <p><strong>PRICE</strong> ${esc(l.price)}</p>
            <p><strong>CONTACT</strong> ${esc(l.contact||'Not provided')}</p>
            <p><strong>DETAILS</strong> ${esc(l.desc||'None')}</p>
            <p><strong>LISTED BY</strong> ${esc(l.listedBy)}</p>
            <p><strong>POSTED</strong> ${l.date}</p>
            <button class="modal-btn tr-mb">▶ CONTACT SELLER</button>`;
        this.openModal();
    }

    // ── DELETE ───────────────────────────────
    delAcc(id){
        if(sessionStorage.getItem('pubg_role')!=='admin') return;
        if(confirm('Delete this account and its photos?')){
            this.accounts=this.accounts.filter(x=>x.id!==id);
            this.saveAccounts();
            deleteMedia(`acc_${id}`); // remove from IndexedDB too
            this.renderAccounts();
        }
    }
    delUC(id){
        if(sessionStorage.getItem('pubg_role')!=='admin') return;
        if(confirm('Delete this package?')){ this.uc=this.uc.filter(x=>x.id!==id); this.saveUC(); this.renderUC(); }
    }
    delTr(id){
        if(sessionStorage.getItem('pubg_role')!=='admin') return;
        if(confirm('Delete this listing and its photos?')){
            this.trade=this.trade.filter(x=>x.id!==id);
            this.saveTrade();
            deleteMedia(`tr_${id}`);
            this.renderTrade();
        }
    }

    // ── MODAL ────────────────────────────────
    bindModal(){ document.getElementById('modal').addEventListener('click',e=>{ if(e.target.id==='modal') closeModal(); }); }
    openModal() { document.getElementById('modal').classList.add('show'); }

    // ── SEARCH ───────────────────────────────
    bindSearch(){
        const si=document.getElementById('global-search');
        si.addEventListener('input',e=>{
            const q=e.target.value.trim();
            document.getElementById('search-clear').classList.toggle('visible',q.length>0);
            clearTimeout(this.stTimeout);
            this.stTimeout=setTimeout(()=>this.doSearch(q),180);
        });
        si.addEventListener('focus',()=>{ if(si.value.trim()) this.doSearch(si.value.trim()); });
        document.addEventListener('click',e=>{ if(!e.target.closest('.search-zone')) document.getElementById('search-results').classList.remove('open'); });
    }

    doSearch(q){
        const el=document.getElementById('search-results');
        if(!q){ el.classList.remove('open'); return; }
        const lq=q.toLowerCase();
        const match=(item,fields)=>fields.some(f=>(item[f]||'').toString().toLowerCase().includes(lq));
        const aM=this.accounts.filter(a=>match(a,['username','rank','level','items','price','description']));
        const uM=this.uc.filter(u=>match(u,['name','amount','price','mobileId','details']));
        const tM=this.trade.filter(l=>match(l,['title','game','price','contact','desc']));
        if(!aM.length&&!uM.length&&!tM.length){
            el.innerHTML=`<div class="sd-empty">// NO RESULTS FOR "${esc(q)}"</div>`;
            el.classList.add('open'); return;
        }
        let html='';
        if(aM.length){
            html+=`<div class="sd-head">// ACCOUNTS (${aM.length})</div>`;
            aM.slice(0,5).forEach(a=>{
                const t=a.media&&a.media.length?`<img src="${a.media[0].dataUrl}">`:'⚔';
                html+=`<div class="sd-item" onclick="market.jumpTo('accounts',${a.id})">
                    <div class="sd-thumb">${t}</div>
                    <div class="sd-info"><div class="sd-title">${esc(a.username)}</div><div class="sd-sub">Lvl ${esc(a.level)} · ${esc(a.items||'Various')}</div></div>
                    <div class="sd-price">${esc(a.price)}</div></div>`;
            });
        }
        if(uM.length){
            html+=`<div class="sd-head">// UC PACKAGES (${uM.length})</div>`;
            uM.slice(0,5).forEach(u=>{
                html+=`<div class="sd-item" onclick="market.jumpTo('uc',${u.id})">
                    <div class="sd-thumb">💎</div>
                    <div class="sd-info"><div class="sd-title">${esc(u.name)}</div><div class="sd-sub">${esc(u.amount)} UC</div></div>
                    <div class="sd-price">${esc(u.price)}</div></div>`;
            });
        }
        if(tM.length){
            html+=`<div class="sd-head">// TRADE (${tM.length})</div>`;
            tM.slice(0,5).forEach(l=>{
                const t=l.media&&l.media.length?`<img src="${l.media[0].dataUrl}">`:'📱';
                html+=`<div class="sd-item" onclick="market.jumpTo('trade',${l.id})">
                    <div class="sd-thumb">${t}</div>
                    <div class="sd-info"><div class="sd-title">${esc(l.title)}</div><div class="sd-sub">${esc(l.game)}</div></div>
                    <div class="sd-price">${esc(l.price)}</div></div>`;
            });
        }
        el.innerHTML=html; el.classList.add('open');
    }

    jumpTo(section, id){
        document.getElementById('search-results').classList.remove('open');
        document.getElementById('global-search').value='';
        document.getElementById('search-clear').classList.remove('visible');
        const btn=document.querySelector(`.ntab[data-page="${section}"]`);
        if(btn){
            document.querySelectorAll('.ntab').forEach(b=>b.classList.remove('active')); btn.classList.add('active');
            document.querySelectorAll('.pg').forEach(s=>s.classList.remove('active'));
            document.getElementById(`${section}-page`).classList.add('active');
        }
        setTimeout(()=>{ if(section==='accounts') this.viewAcc(id); else if(section==='uc') this.viewUC(id); else this.viewTr(id); },280);
    }
}

function closeModal(){ document.getElementById('modal').classList.remove('show'); }

// ── BOOT ─────────────────────────────────────
const market = new Market();
